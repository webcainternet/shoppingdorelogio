<?php

namespace Tritoq\Payment\Exception;


class InvalidArgumentException extends \Exception
{

} 