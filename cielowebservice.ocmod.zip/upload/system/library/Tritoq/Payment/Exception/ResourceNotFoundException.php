<?php

namespace Tritoq\Payment\Exception;


class ResourceNotFoundException extends \Exception
{

} 