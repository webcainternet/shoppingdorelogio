<?php
require_once(dirname(__FILE__) . '/Tritoq/TritoqAutoloader.php');

TritoqAutoloader::register();